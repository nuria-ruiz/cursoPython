function Header() {
  return (
    <header className="header">
      <h1>Mi Aplicación React</h1>
      <h2>Mi primera app con react</h2>
    </header>
  );
}

export default Header;