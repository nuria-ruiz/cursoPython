import stats

print(stats.mean(6, 3, 9, 5))

print(stats.std(6, 3, 9, 5))

