def hi():
    return print('blablablablablaaa')