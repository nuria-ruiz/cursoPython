import "./App.css";
import TagInput from "./component/TagInput";

function App() {
  return (
    <div className="App">
      <TagInput />
    </div>
  );
}

export default App;
