## Demo002

Practicas con React y Socket.io

## Demo:

![Imgur](https://i.imgur.com/Y7fR51V.png)