## Ejemplo React y Redux

![Imgur](https://i.imgur.com/rl19wK0.png)