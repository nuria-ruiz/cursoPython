### Estadisticas con React

![Imgur](https://i.imgur.com/T5ZhV6z.png)