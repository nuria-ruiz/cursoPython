import React from "react";

import JokesManager from "./modules/joke/components/JokesManager";

const App = () => (
  <div>
    <h1> Chistes de Chuck Norris</h1>
    <JokesManager />
  </div>
);

export default App;