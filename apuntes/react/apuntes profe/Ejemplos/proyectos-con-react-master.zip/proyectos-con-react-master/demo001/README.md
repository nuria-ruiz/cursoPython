## Demo 001

- Obtener chistes de una api rest
- Reducir una app React / Redux con require.context y estructura de módulos
- Borrar chistes de la lista

### Demo

![Imgur](https://i.imgur.com/i5wlgBB.png)