## Texto Enriquecido con Draft.js

![Imgur](https://i.imgur.com/Iz8BADF.png)