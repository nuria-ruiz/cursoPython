### Proyectos en React

- [Demo01](https://github.com/Beor18/proyectos-con-react/tree/master/demo001) - Obtener y borrar chistes de una api rest y reducir una app React / Redux con require.context y estructura de módulos.

- [Demo02](https://github.com/Beor18/proyectos-con-react/tree/master/demo002) - Obtener total de registros de una base de datos y mostrar el total en tiempo real

- [Demo03](https://github.com/Beor18/proyectos-con-react/tree/master/demo003) - Lista de notas con redux

- [Demo04](https://github.com/Beor18/proyectos-con-react/tree/master/demo004) - Probando Material UI

- [Demo05](https://github.com/Beor18/proyectos-con-react/tree/master/demo005) - Texto Enriquecido con Draft.js

- [Demo06](https://github.com/Beor18/proyectos-con-react/tree/master/demo006) - Portfolio Personal

- [Demo07](https://github.com/Beor18/proyectos-con-react/tree/master/demo007) - Estadisticas con React

- [Demo08](https://github.com/Beor18/proyectos-con-react/tree/master/demo008) - Varios temas

- [Demo09](https://github.com/Beor18/proyectos-con-react/tree/master/demo009) - Buscador de Hoteles con Hooks

- [Demo010](https://github.com/Beor18/proyectos-con-react/tree/master/demo010) - Bulma UI + React Router

- [Demo011](https://github.com/Beor18/proyectos-con-react/tree/master/demo011) - Autocompletado Componente con React
